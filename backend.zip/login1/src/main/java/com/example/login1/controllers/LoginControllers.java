package com.example.login1.controllers;

import java.util.List;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.login1.entity.AuthRequest;
import com.example.login1.entity.UserCC;
import com.example.login1.entity.UserRecord;
import com.example.login1.repository.UserRepository;
import com.example.login1.repository.UserRepositoryrecord;
import com.example.login1.service.JwtService;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import com.example.login1.entity.Records;

@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:3000")
public class LoginControllers {
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserRepositoryrecord userRepository1;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private JwtService jwtService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	
	 DateTimeFormatter dtf1 = DateTimeFormatter.ofPattern("yyyy/MM/dd");  
	 DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("HH:mm:ss");  
	
	@PostMapping("/newuser")
	public ResponseEntity<UserCC> userClass(@RequestBody UserCC userCC){
		userCC.setPassword(passwordEncoder.encode(userCC.getPassword()));
		UserCC saved=userRepository.save(userCC);
		return new ResponseEntity<>(saved,HttpStatus.OK);
	}
	
	
	@GetMapping("/admin")
	  @PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public ResponseEntity<String> adminClass(){
		return new ResponseEntity<>("admin World",HttpStatus.OK);
	}
	
	@GetMapping("/public")
	public ResponseEntity<String> publicClass(){
		return new ResponseEntity<>("public World",HttpStatus.OK);
	}
	
	@PostMapping("/authenticate")
	public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
		org.springframework.security.core.Authentication	authentication=authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getName(),authRequest.getPassword()));
		if(authentication.isAuthenticated()) {
		return jwtService.generateToken(authRequest.getName());
		}else {
			throw  new UsernameNotFoundException("invalid user request");
		}
	}
	
	
	@GetMapping("/all")
	public ResponseEntity<List<UserCC>> findAllStudents(){
		List<UserCC> list = userRepository.findAll();
		return new ResponseEntity<>(list,HttpStatus.OK);
	}
	@CrossOrigin(origins="*",allowedHeaders="*")
	@PostMapping("/saverecord")
	public ResponseEntity<Records> saveRecord(@RequestBody Records userrecord){
		 LocalDateTime now = LocalDateTime.now();  
		   userrecord.setDate(dtf1.format(now));
		   userrecord.setTime(dtf2.format(now));
	      Records saved=userRepository1.save(userrecord);
		return new ResponseEntity<>(saved,HttpStatus.CREATED);
	}
//with user name
	@CrossOrigin(origins="*",allowedHeaders="*")
	@GetMapping("/showrecord")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public ResponseEntity<List<Records>> showRecord(){
		List<Records> list = userRepository1.findAll();
		return new ResponseEntity<>(list,HttpStatus.OK);
	}
	@CrossOrigin(origins="*",allowedHeaders="*")
	@PostMapping("/isadmin")
	ResponseEntity<String>isAdmin(@RequestBody AuthRequest authRequest) {
		String roles=userRepository.getRoleByName(authRequest.getName());
		boolean b=false;
//		if(roles.contains("ROLE_USER"))
//			b=true;
		
	return  new ResponseEntity<>(roles,HttpStatus.OK);
	}
}
