package com.example.login1.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.login1.entity.Records;

public interface UserRepositoryrecord extends MongoRepository<Records,String>{


}
