package com.example.login1.entity;


import org.springframework.data.mongodb.core.mapping.Document;

public class UserRecord {

	private String firstname;
	
	private String lastname;
	
	private String role;
	
	private String email;
	
	private String street;
	
	private String state;
	
	private String city;
	
	private int pincode;
	
	private String userid;

	UserRecord(String firstname, String lastname, String role, String email, String street, String state,
			String city, int pincode, String userid) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.role = role;
		this.email = email;
		this.street = street;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.userid = userid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
	
}

