package com.example.login1.repository;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.login1.entity.UserCC;



public interface UserRepository extends MongoRepository<UserCC,String>  {

	Optional<UserCC> findById(String username);

	





	String getRoleByName(String name);

	

	

	



}
